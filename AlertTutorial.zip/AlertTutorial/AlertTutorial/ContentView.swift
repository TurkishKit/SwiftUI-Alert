//
//  ContentView.swift
//  AlertTutorial
//
//  Created by Ufuk Kosker on 11.01.2021.
//

import SwiftUI

struct ContentView: View {
    @State private var uyariGoster = false
    @State var text: String = ""
    var body: some View {
        Button(action: {
            self.uyariGoster = true
        }) {
            Text("Uyarı Göster")
        }
        .alert(isPresented: $uyariGoster, content: {
            Alert(title: Text("TK Akademi"), message: Text("TK Akademi başlıyor. Hemen kaydını oluştur."), primaryButton: .default(Text("Kayıt Ol"), action: {
                text = "Kayıt oluşturuldu."
            }),secondaryButton: .destructive(Text("İptal")))

        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
